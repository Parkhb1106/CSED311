// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vvending_machine.h for the primary calling header

#include "Vvending_machine__pch.h"
#include "Vvending_machine__Syms.h"
#include "Vvending_machine___024root.h"

void Vvending_machine___024root___ctor_var_reset(Vvending_machine___024root* vlSelf);

Vvending_machine___024root::Vvending_machine___024root(Vvending_machine__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vvending_machine___024root___ctor_var_reset(this);
}

void Vvending_machine___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

Vvending_machine___024root::~Vvending_machine___024root() {
}
